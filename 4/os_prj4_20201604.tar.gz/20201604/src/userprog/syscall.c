#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "devices/shutdown.h"
#include "filesys/off_t.h"
struct file
  {
    struct inode *inode;        /* File's inode. */
    off_t pos;                  /* Current position. */
    bool deny_write;            /* Has file_deny_write() been called? */
  };
static void syscall_handler (struct intr_frame *);
struct lock sync_lock;
void
syscall_init (void) 
{
  lock_init(&sync_lock);
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

void halt(void)
{
  shutdown_power_off();
}

void exit(int status)
{
  printf("%s: exit(%d)\n", thread_current()->name, status);
  //printf("%s: exit(%d)<%d>\n", thread_current()->name, status, thread_current()->tid);
  //if(thread_current()->load_flag==0){
    //sema_up(&(thread_current()->parent->sema_load));
    //thread_current()->load_flag=1;
  //}
  thread_current()->exit_status = status;
  for(int i = 2; i < 128; i++) 
    if(thread_current()->fd[i] != NULL) close(i);
  struct list_elem *e;
  struct thread* curr;
  for(e = list_begin(&thread_current()->list_child); e != list_end(&thread_current()->list_child); e = list_next(e)) {
    curr = list_entry(e, struct thread, elem_child);
    process_wait(curr->tid);
  }
  thread_exit(); 
}

pid_t exec (const char *cmd_line) {
  return process_execute(cmd_line);
}

int wait (pid_t pid) {
  return process_wait(pid);
}

int read (int fd, void* buffer, unsigned size) {
  safe_addr(buffer);
  //printf("read-lock-acq: %d\n", thread_current()->tid);
  lock_acquire(&sync_lock);
  int ret = -1;
  int i;
  if(fd == 0){
    for(i = 0; i < size ; i++) {
        if(input_getc() == '\0')
          break;
    }
    ret = i;
  }
  else if(fd > 1){
    if(thread_current()->fd[fd] == NULL){
      exit(-1);
    }
    ret = file_read(thread_current()->fd[fd], buffer, size);
  }
  //printf("read-lock-rel: %d\n", thread_current()->tid);
  lock_release(&sync_lock);
  return ret;
}

int write (int fd, const void *buffer, unsigned size) {
  int ret = -1;
  safe_addr(buffer);
  //printf("write-lock-acq: %d\n", thread_current()->tid);
  lock_acquire(&sync_lock);
  if(fd == 1) {
    putbuf(buffer, size);
    ret = size;
  }
  else if (fd > 1) {
    if(thread_current()->fd[fd] == NULL){
      //printf("1. write-lock-rel: %d\n", thread_current()->tid);
      lock_release(&sync_lock);
      exit(-1);
    }
    if(thread_current()->fd[fd]->deny_write) {
      file_deny_write(thread_current()->fd[fd]);
    }
    ret = file_write(thread_current()->fd[fd], buffer, size);
  }
  //printf("2. write-lock-rel: %d\n", thread_current()->tid);
  lock_release(&sync_lock);
  return ret;
}

void safe_addr(void* addr)
{
  if(!is_user_vaddr(addr)){
    //printf("wrong addr\n");
    exit(-1);
  }
  if(!addr){
    //printf("wrong addr\n");
    exit(-1);
  }
}

int open(const char *file)
{
  if(!file){
    //printf("open null file\n");
    exit(-1);
  }
  //printf("open-lock-acq: %d\n", thread_current()->tid);
  lock_acquire(&sync_lock);
  int ret = -1;
  struct file* new_file = filesys_open(file);
  if(!new_file)  ret = -1;
  else{
    for(int i = 2; i < 128; i++) {
      if(!(thread_current()->fd[i])) {
        if(strcmp(thread_current()->name, file) == 0)//
          file_deny_write(new_file);
        thread_current()->fd[i] = new_file;
        ret = i;
        break;
      }
    }
  }
  //printf("open-lock-rel: %d\n", thread_current()->tid);
  lock_release(&sync_lock);
  return ret;
}

bool create(const char *file, unsigned initial_size)
{
  if(!file){
    //printf("create null file\n");
    exit(-1);
  }
  return filesys_create(file, initial_size);
}

bool remove(const char* file)
{
  if(!file){
    exit(-1);
  }
  return filesys_remove(file);
}

void close(int fd)
{
  if(thread_current()->fd[fd] == NULL){
    exit(-1);
  } 
  file_close(thread_current()->fd[fd]);
  thread_current()->fd[fd] = NULL;
}

int filesize(int fd)
{
  return file_length(thread_current()->fd[fd]);
}

void seek(int fd, unsigned position)
{
  file_seek(thread_current()->fd[fd], position);
}

unsigned tell(int fd)
{
  return file_tell(thread_current()->fd[fd]);
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
  switch (*(uint32_t *)(f->esp)) 
  {
  case SYS_HALT :
    halt();
    break;
  case SYS_EXIT :
    safe_addr(f->esp + 4);
    exit(*(uint32_t *)(f->esp + 4));
    break;
  case SYS_EXEC :
    safe_addr(f->esp + 4);
    f->eax = exec(*(uint32_t *)(f->esp + 4));
    break;
  case SYS_WAIT :
    safe_addr(f->esp + 4);
    f->eax = wait(*(uint32_t *)(f->esp + 4));
    break;
  case SYS_WRITE :
    safe_addr(f->esp + 12);
    safe_addr(f->esp + 8);
    safe_addr(f->esp + 4);
    f->eax = write(*(uint32_t *)(f->esp+4), *(uint32_t *)(f->esp + 8), *(uint32_t *)(f->esp + 12));
    break;
  case SYS_READ :
    safe_addr(f->esp + 12);
    safe_addr(f->esp + 8);
    safe_addr(f->esp + 4);
    f->eax = read(*(uint32_t *)(f->esp+4), *(uint32_t *)(f->esp + 8), *(uint32_t *)(f->esp + 12));
    break;
  case SYS_CREATE :
    safe_addr(f->esp + 4);
    safe_addr(f->esp + 8);
    f->eax = create(*(uint32_t *)(f->esp+4), *(uint32_t *)(f->esp+8));
    break;
  case SYS_REMOVE :
    safe_addr(f->esp + 4);
    f->eax = remove(*(uint32_t *)(f->esp+4));
    break;
  case SYS_OPEN :
    safe_addr(f->esp +4);
    f->eax = open(*(uint32_t *)(f->esp+4));
    break;
  case SYS_CLOSE :
    safe_addr(f->esp +4);
    close(*(uint32_t *)(f->esp+4));
    break;
  case SYS_FILESIZE :
    safe_addr(f->esp +4);
    f->eax = filesize(*(uint32_t *)(f->esp+4));
    break;
  case SYS_SEEK :
    safe_addr(f->esp +4);
    safe_addr(f->esp + 8);
    seek(*(uint32_t *)(f->esp+4), *(uint32_t *)(f->esp+8));
    break;
  case SYS_TELL :
    safe_addr(f->esp +4);
    f->eax = tell(*(uint32_t *)(f->esp+4));
    break;
  default:
    exit(-1);
    break;
  }
}
