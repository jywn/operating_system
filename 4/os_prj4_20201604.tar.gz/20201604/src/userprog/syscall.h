#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H
#include "lib/user/syscall.h"
#include "threads/vaddr.h"
#include "devices/shutdown.h"

void syscall_init(void);
void halt(void);
pid_t exec(const char *cmd_line);
int wait(pid_t pid);
int open(const char *file);
int read(int fd, void *buffer, unsigned size);
int write(int fd, const void *buffer, unsigned size);
void safe_addr(void* addr);
void exit(int status);
int fibonacci(int n);
int max_of_four_int(int a, int b, int c, int d);
/*project 2*/
int open(const char *file);
/*
Opens the file called file. Returns a nonnegative integer handle called a “file descriptor” (fd), or -1 if the file could not be opened.
File descriptors numbered 0 and 1 are reserved for the console: fd 0 (STDIN_FILENO) is
standard input, fd 1 (STDOUT_FILENO) is standard output. The open system call will
never return either of these file descriptors, which are valid as system call arguments
only as explicitly described below.
Each process has an independent set of file descriptors. File descriptors are not
inherited by child processes.
When a single file is opened more than once, whether by a single process or different
processes, each open returns a new file descriptor. Different file descriptors for a single
file are closed independently in separate calls to close and they do not share a file
position.
*/
bool create(const char *file, unsigned initial_size);
/*
Creates a new file called file initially initial size bytes in size. Returns true if successful, false otherwise. Creating a new file does not open it: opening the new file is
a separate operation which would require a open system call.
*/
bool remove(const char *file);
/*
Deletes the file called file. Returns true if successful, false otherwise. A file may be
removed regardless of whether it is open or closed, and removing an open file does
not close it. See [Removing an Open File], page 35, for details.
*/
void close(int fd);
/*
Closes file descriptor fd. Exiting or terminating a process implicitly closes all its open
file descriptors, as if by calling this function for each one.
*/
int filesize(int fd);
/*
Returns the size, in bytes, of the file open as fd.
*/
void seek(int fd, unsigned position);
/*
Changes the next byte to be read or written in open file fd to position, expressed in
bytes from the beginning of the file. (Thus, a position of 0 is the file’s start.)
A seek past the current end of a file is not an error. A later read obtains 0 bytes,
indicating end of file. A later write extends the file, filling any unwritten gap with
zeros. (However, in Pintos files have a fixed length until project 4 is complete, so
writes past end of file will return an error.) These semantics are implemented in the
file system and do not require any special effort in system call implementation.
*/
unsigned tell(int fd);
/*
Returns the position of the next byte to be read or written in open file fd, expressed
in bytes from the beginning of the file.
*/
#endif /* userprog/syscall.h */
