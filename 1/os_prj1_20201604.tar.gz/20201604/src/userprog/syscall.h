#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H
#include "lib/user/syscall.h"
#include "threads/vaddr.h"
#include "devices/shutdown.h"

void syscall_init(void);
void halt(void);
pid_t exec(const char *cmd_line);
int wait(pid_t pid);
int open(const char *file);
int read(int fd, void *buffer, unsigned size);
int write(int fd, const void *buffer, unsigned size);
void safe_addr(void* addr);
void exit(int status);
#endif /* userprog/syscall.h */
